import Foundation

@objc(FanControl)

class FanControl : NSObject {
    
    ///MARK: Inputs
    var temperatureDegrees = "0"

    //MARK: System Under Test
    lazy var fanController: FanController = {
        let thermostat = Thermostat()
        return FanController(thermostat:thermostat)
    }()
    
    
    ///MARK: Decision Table Calls
    func execute() {
        fanController.thermostat.temp = Int(temperatureDegrees)!
    }
    
    //MARK: Outputs
    var fan: NSString {
        get {
            return NSString(string:fanController.fan.state.description)
        }
    }
    
    var heater: NSString {
        get {
            return NSString(string:fanController.heater.state.description)
        }
    }
    
    
    
    
    
}