import Foundation

protocol SlimDecisionTable {

	func execute()
} 