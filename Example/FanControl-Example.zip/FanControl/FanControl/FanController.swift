import Foundation

struct FanController: ThermostatObserver {

    let fan = Fan()
    let heater = Heater()
    let thermostat: Thermostat
    
    init(thermostat: Thermostat) {
        self.thermostat = thermostat
        self.thermostat.observer = self
    }
    
    func observeredThermostatChange(temperature: Int) {
        
        switch temperature {
        case 0...20:
            fan.state = .off
            heater.state = .on
        case 21:
            fan.state = .off
            heater.state = .off
        default:
            fan.state = .on
            heater.state = .off
        }
    }

}
