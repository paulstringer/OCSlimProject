import Foundation

enum SwitchState: CustomStringConvertible {
    
    case on
    case off
    
    var description: String {
        get {
            switch self {
            case .off: return "off"
            case .on: return "on"
            }
        }
    }
}

protocol Switchable {
    var state: SwitchState { get set }
}

class Fan : Switchable {
    var state = SwitchState.off
}

class Heater : Switchable {
    var state = SwitchState.off
}