import Foundation

protocol ThermostatObserver {
    
    func observeredThermostatChange(temperature: Int) -> Void
    
}

class Thermostat {
    
    var observer: ThermostatObserver?
    
    var temp = 18 {
        didSet {
            observer?.observeredThermostatChange(temp)
        }
    }

}